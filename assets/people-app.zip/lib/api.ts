const BASE_URL = "https://metasite-fe-task-api.azurewebsites.net/api/v1"

interface GetContactsParams {
  page?: number
  limit?: number
  country?: string
  city?: string
  fullName?: string
}

class ContactsAPI {
  private getAuthHeaders() {
    const token = localStorage.getItem("auth_token")
    return {
      "Content-Type": "application/json",
      ...(token && { Authorization: `Bearer ${token}` }),
    }
  }

  async getContacts(params: GetContactsParams = {}) {
    const { page = 1, limit = 20, country, city, fullName } = params

    const searchParams = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
    })

    if (country) searchParams.append("country", country)
    if (city) searchParams.append("city", city)
    if (fullName) searchParams.append("fullName", fullName)

    const response = await fetch(`${BASE_URL}/list?${searchParams.toString()}`, {
      headers: this.getAuthHeaders(),
    })

    if (!response.ok) {
      if (response.status === 401) {
        // Token expired, redirect to login
        localStorage.removeItem("auth_token")
        window.location.href = "/login"
        throw new Error("Authentication required")
      }
      throw new Error("Failed to fetch contacts")
    }

    return response.json()
  }

  async getContact(id: string) {
    const response = await fetch(`${BASE_URL}/list-item?id=${id}`, {
      headers: this.getAuthHeaders(),
    })

    if (!response.ok) {
      if (response.status === 401) {
        // Token expired, redirect to login
        localStorage.removeItem("auth_token")
        window.location.href = "/login"
        throw new Error("Authentication required")
      }
      throw new Error("Failed to fetch contact")
    }

    return response.json()
  }
}

export const contactsApi = new ContactsAPI()
