"use client"

import { Card, CardContent } from "@/components/ui/card"
import type { Contact } from "@/types/contact"
import { MapPin } from "lucide-react"
import Image from "next/image"

interface ContactCardProps {
  contact: Contact
  onClick: () => void
}

export function ContactCard({ contact, onClick }: ContactCardProps) {
  const fullName = `${contact.name} ${contact.surname}`

  return (
    <Card
      className="cursor-pointer hover:shadow-lg transition-shadow duration-200 border-0 shadow-md"
      onClick={onClick}
    >
      <CardContent className="p-0">
        <div className="relative">
          <div className="aspect-[4/3] relative overflow-hidden rounded-t-lg">
            <Image
              src={contact.imageSrc || "/placeholder.svg?height=240&width=320"}
              alt={fullName}
              fill
              className="object-cover"
            />
          </div>
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
            <h3 className="text-white font-semibold text-lg mb-1">{fullName}</h3>
            <div className="flex items-center text-white/90 text-sm">
              <MapPin size={14} className="mr-1" />
              <span>
                {contact.city}, {contact.country}
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
