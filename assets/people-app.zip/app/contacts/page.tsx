"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAuth } from "@/lib/auth-context"
import { ContactCard } from "@/components/contact-card"
import { Search, LogOut, Filter, X } from "lucide-react"
import type { Contact, ContactsResponse, PaginationInfo } from "@/types/contact"
import { contactsApi } from "@/lib/api"
import { useDebounce } from "@/hooks/use-debounce"

export default function ContactsPage() {
  const [contacts, setContacts] = useState<Contact[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [countryFilter, setCountryFilter] = useState("")
  const [cityFilter, setCityFilter] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isLoadingMore, setIsLoadingMore] = useState(false)
  const [pagination, setPagination] = useState<PaginationInfo | null>(null)
  const [availableCountries, setAvailableCountries] = useState<string[]>([])
  const [availableCities, setAvailableCities] = useState<string[]>([])
  const { logout, isAuthenticated } = useAuth()
  const router = useRouter()

  // Debounce search and filter terms
  const debouncedSearchTerm = useDebounce(searchTerm, 300)
  const debouncedCityFilter = useDebounce(cityFilter, 300)

  const loadContacts = useCallback(
    async (page = 1, reset = false, filters = {}) => {
      try {
        if (page === 1) {
          setIsLoading(true)
        } else {
          setIsLoadingMore(true)
        }

        const params = {
          page,
          limit: 20,
          ...filters,
        }

        const response: ContactsResponse = await contactsApi.getContacts(params)

        if (reset || page === 1) {
          setContacts(response.data)

          // Extract unique countries and cities for filter options
          const countries = [...new Set(response.data.map((contact) => contact.country))].sort()
          const cities = [...new Set(response.data.map((contact) => contact.city))].sort()
          setAvailableCountries(countries)
          setAvailableCities(cities)
        } else {
          setContacts((prev) => [...prev, ...response.data])
        }

        setPagination(response.pagination)
      } catch (error) {
        console.error("Failed to load contacts:", error)
        if (error instanceof Error && error.message === "Authentication required") {
          logout()
          router.push("/login")
        }
      } finally {
        setIsLoading(false)
        setIsLoadingMore(false)
      }
    },
    [logout, router],
  )

  // Build current filters object
  const getCurrentFilters = useCallback(() => {
    const filters: any = {}
    if (debouncedSearchTerm) filters.fullName = debouncedSearchTerm
    if (countryFilter) filters.country = countryFilter
    if (debouncedCityFilter) filters.city = debouncedCityFilter
    return filters
  }, [debouncedSearchTerm, countryFilter, debouncedCityFilter])

  // Load initial contacts
  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }
    loadContacts(1, true)
  }, [isAuthenticated, router, loadContacts])

  // Handle filter changes
  useEffect(() => {
    const filters = getCurrentFilters()
    loadContacts(1, true, filters)
  }, [debouncedSearchTerm, countryFilter, debouncedCityFilter, loadContacts, getCurrentFilters])

  const handleLoadMore = () => {
    if (pagination && pagination.page < pagination.totalPages) {
      const filters = getCurrentFilters()
      loadContacts(pagination.page + 1, false, filters)
    }
  }

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  const handleContactClick = (contact: Contact) => {
    router.push(`/contacts/${contact.id}`)
  }

  const clearFilters = () => {
    setSearchTerm("")
    setCountryFilter("")
    setCityFilter("")
  }

  const hasActiveFilters = searchTerm || countryFilter || cityFilter
  const hasMore = pagination ? pagination.page < pagination.totalPages : false

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <h1 className="text-xl font-bold text-blue-600">PeopleComp</h1>
            <Button onClick={handleLogout} variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900">
              <LogOut size={16} className="mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Search and Filters */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="space-y-4">
          {/* Search Bar */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <Input
                type="text"
                placeholder="Search by name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 h-11"
              />
            </div>
            <Button variant="outline" className="h-11 px-4" onClick={() => setShowFilters(!showFilters)}>
              <Filter size={16} className="mr-2" />
              Filters
              {hasActiveFilters && (
                <span className="ml-2 bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {[searchTerm, countryFilter, cityFilter].filter(Boolean).length}
                </span>
              )}
            </Button>
          </div>

          {/* Advanced Filters */}
          {showFilters && (
            <div className="bg-white p-4 rounded-lg border border-gray-200 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-gray-900">Filters</h3>
                {hasActiveFilters && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    <X size={16} className="mr-1" />
                    Clear all
                  </Button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Country</label>
                  <Select value={countryFilter} onValueChange={setCountryFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All countries</SelectItem>
                      {availableCountries.map((country) => (
                        <SelectItem key={country} value={country}>
                          {country}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">City</label>
                  <Input
                    type="text"
                    placeholder="Filter by city..."
                    value={cityFilter}
                    onChange={(e) => setCityFilter(e.target.value)}
                    className="h-10"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Results count and pagination info */}
        {pagination && (
          <div className="mb-4 mt-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <p className="text-sm text-gray-600">
              Showing {contacts.length} of {pagination.total} contacts
            </p>
            <p className="text-sm text-gray-500">
              Page {pagination.page} of {pagination.totalPages}
            </p>
          </div>
        )}

        {/* Loading state for initial load */}
        {isLoading && contacts.length === 0 && (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        )}

        {/* Contacts Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {contacts.map((contact) => (
            <ContactCard key={contact.id} contact={contact} onClick={() => handleContactClick(contact)} />
          ))}
        </div>

        {/* Load More */}
        {hasMore && (
          <div className="flex justify-center mt-8">
            <Button onClick={handleLoadMore} disabled={isLoadingMore} variant="outline" className="px-8">
              {isLoadingMore ? "Loading..." : "Load More"}
            </Button>
          </div>
        )}

        {/* Empty State */}
        {contacts.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <p className="text-gray-500">
              {hasActiveFilters ? "No contacts found matching your filters" : "No contacts found"}
            </p>
            {hasActiveFilters && (
              <Button variant="outline" onClick={clearFilters} className="mt-4">
                Clear filters
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
