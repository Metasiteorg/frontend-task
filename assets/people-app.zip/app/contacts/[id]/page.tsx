"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useAuth } from "@/lib/auth-context"
import { ArrowLeft, Mail, Phone, MapPin } from "lucide-react"
import type { Contact } from "@/types/contact"
import { contactsApi } from "@/lib/api"
import Image from "next/image"

export default function ContactDetailPage() {
  const [contact, setContact] = useState<Contact | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const { isAuthenticated } = useAuth()
  const router = useRouter()
  const params = useParams()
  const contactId = params.id as string

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }

    const loadContact = async () => {
      try {
        setIsLoading(true)
        const contactData = await contactsApi.getContact(contactId)
        setContact(contactData)
      } catch (error) {
        console.error("Failed to load contact:", error)
        router.push("/contacts")
      } finally {
        setIsLoading(false)
      }
    }

    if (contactId) {
      loadContact()
    }
  }, [contactId, isAuthenticated, router])

  if (!isAuthenticated || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!contact) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Contact not found</p>
      </div>
    )
  }

  const fullName = `${contact.name} ${contact.surname}`

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Button onClick={() => router.back()} variant="ghost" size="sm" className="mr-4">
              <ArrowLeft size={16} className="mr-2" />
              Back
            </Button>
            <h1 className="text-xl font-bold text-blue-600">PeopleComp</h1>
          </div>
        </div>
      </header>

      {/* Contact Details */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="shadow-lg border-0">
          <CardContent className="p-8">
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Profile Image */}
              <div className="flex-shrink-0">
                <div className="w-48 h-48 mx-auto lg:mx-0">
                  <Image
                    src={contact.imageSrc || "/placeholder.svg?height=192&width=192"}
                    alt={fullName}
                    width={192}
                    height={192}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>
              </div>

              {/* Contact Information */}
              <div className="flex-1 space-y-6">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">{fullName}</h1>
                  <p className="text-lg text-gray-600">
                    {contact.city}, {contact.country}
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Mail className="h-5 w-5 text-gray-500" />
                    <a href={`mailto:${contact.email}`} className="text-blue-600 hover:underline">
                      {contact.email}
                    </a>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-5 w-5 text-gray-500" />
                    <span>{contact.phone}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-gray-500" />
                    <span>
                      {contact.address}, {contact.city}, {contact.country}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
